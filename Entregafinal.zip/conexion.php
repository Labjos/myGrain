
<?php
$datos_bd=mysqli_connect("localhost", "root", "","areas" ) or die ("Error de conexion con base de datos");


?>